#配置jdk环境
export JAVA_HOME=/sdcard/SHC/tools/java
export AndroidSDK=/sdcard/SHC/tools/java/bin/aapt
export CLASSPATH=.:$CLASSPATH:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export PATH=$PATH:$JAVA_HOME/bin
export JRE_HOME=$JAVA_HOME/jre
 _classpath=/sdcard/SHC/tools/jar/dex2jar/lib/asm-all-3.3.1.jar:/sdcard/SHC/tools/jar/dex2jar/lib/commons-lite-1.15.jar:/sdcard/SHC/tools/jar/dex2jar/lib/dex-ir-1.12.jar:/sdcard/SHC/tools/jar/dex2jar/lib/dex-reader-1.15.jar:/sdcard/SHC/tools/jar/dex2jar/lib/dex-tools-0.0.9.15.jar:/sdcard/SHC/tools/jar/dex2jar/lib/dex-translator-0.0.9.15.jar:/sdcard/SHC/tools/jar/dex2jar/lib/dx.jar:/sdcard/SHC/tools/jar/dex2jar/lib/jar-rename-1.6.jar:/sdcard/SHC/tools/jar/dex2jar/lib/jasmin-p2.5.jar
java  -Xmx1024m -classpath "${_classpath}" "com.googlecode.dex2jar.tools.Jar2Dex" "$@"
